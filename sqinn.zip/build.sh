#!/bin/sh

if [ ! -d "src" ]; then
    echo src dir not found
    exit 1
fi

if [ ! -d "bin" ]; then
    mkdir bin
fi

CC="mipsel-linux-gnu-gcc"

if [ ! -f "bin/sqlite3.o" ]; then
    echo build sqlite3.o
    $CC -std=c99 -O1 -o bin/sqlite3.o -c src/sqlite3.c -DSQLITE_THREADSAFE=0 -DSQLITE_OMIT_LOAD_EXTENSION
fi

FLAGS="-std=c99 -Wall -O1 -march=24kec"
case `uname -s` in 
    *Linux*)
        FLAGS="$FLAGS -static"
        ;;
    *MINGW*)
        FLAGS="$FLAGS -static"
        ;;
esac

echo build sqinn using FLAGS $FLAGS
$CC $FLAGS -o bin/sqinn \
    src/util.c \
    src/mem.c \
    src/mem_test.c \
    src/conn.c \
    src/conn_test.c \
    src/handler.c \
    src/handler_test.c \
    src/loop.c \
    src/main.c \
    bin/sqlite3.o

echo build-info
BUILDINFO="bin/build-info.txt"
date                      > $BUILDINFO
echo                     >> $BUILDINFO
echo "uname -a"          >> $BUILDINFO
uname -a                 >> $BUILDINFO
echo                     >> $BUILDINFO
echo "gcc --version"     >> $BUILDINFO
gcc --version            >> $BUILDINFO
echo                     >> $BUILDINFO
echo "file bin/sqinn"    >> $BUILDINFO
file bin/sqinn           >> $BUILDINFO



